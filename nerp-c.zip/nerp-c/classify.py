import json
import os

DATA_DIR = "data"
OUTPUT_DIR = "output"

os.makedirs(OUTPUT_DIR, exist_ok=True)

files = [
    "incidents.json",
    "responders.json",
    "intelligence.json",
    "dispatch.json",
    "audit.json",
]

LEVELS = {"PUBLIC": 1, "OPERATIONAL": 2, "SENSITIVE": 3, "RESTRICTED": 4}

HINT_MAPPING = {
    "OFFICIAL": "PUBLIC",
    "CONFIDENTIAL": "OPERATIONAL",
    "SECRET": "SENSITIVE",
    "TOP SECRET": "RESTRICTED"
}

def classify_record(dataset, record):
    classification = "PUBLIC"
    integrity_level = "Verified" 
    sensitivity_tags = []
    reasons = []

    
    if dataset == "intelligence.json" and "classificationHint" in record:
        original_hint = record["classificationHint"]
        classification = HINT_MAPPING.get(original_hint, "SENSITIVE") 
        reasons.append(f"Mapped original hint '{original_hint}' to {classification}")
        sensitivity_tags.append("INTELLIGENCE")


    pii_fields = ["callerName", "callerPhone", "name", "suspectIdentifier"]
    for field in pii_fields:
        if field in record and record[field]:
            if "PII" not in sensitivity_tags:
                sensitivity_tags.append("PII")
                reasons.append(f"Contains PII field: {field}")
            
            if LEVELS[classification] < LEVELS["SENSITIVE"]:
                classification = "SENSITIVE"

    
    summary = str(record.get("summary", "")) + str(record.get("incidentType", ""))
    keywords = ["terror", "attack", "malware", "critical infrastructure", "Chemical Spill", "Collapse"]
    for kw in keywords:
        if kw.lower() in summary.lower():
            if "HIGH_RISK" not in sensitivity_tags:
                sensitivity_tags.append("HIGH_RISK")
                reasons.append(f"Keyword detected: {kw}")
            
            if LEVELS[classification] < LEVELS["SENSITIVE"]:
                classification = "SENSITIVE"

    
    if dataset == "audit.json":
        integrity_level = "Trusted"
        sensitivity_tags.append("AUDIT_CRITICAL")
        reasons.append("Audit log requires highest integrity (Trusted)")

    
    sensitivity_tags = list(set(sensitivity_tags))

    
    record["classification"] = classification
    record["integrityLevel"] = integrity_level
    record["sensitivityTags"] = sensitivity_tags
    record["reasons"] = reasons

    return record


for filename in files:
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        records = json.load(f)

    classified_records = []
    for record in records:
        classified_record = classify_record(filename, record)
        classified_records.append(classified_record)

    
    output_path = os.path.join(OUTPUT_DIR, f"classified_{filename}")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(classified_records, f, indent=4)

    print(f"Processed and saved: {output_path}")

print("All processing completed! Check the output folder for ERRS labels.")