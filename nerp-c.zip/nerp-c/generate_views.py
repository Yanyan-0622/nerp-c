import json
import os

OUTPUT_DIR = "output"

files = [
    "classified_incidents.json",
    "classified_responders.json",
    "classified_intelligence.json",
    "classified_dispatch.json",
    "classified_audit.json",
]

operational_view = []
analytics_view = []
research_view = []

def process_record(dataset, record):
    # 1. Operational View (For responders, keep necessary operational details)
    op_record = record.copy()
    if "callerPhone" in op_record:
        op_record["callerPhone"] = "[REDACTED]"  # Mask PII
    # Exclude highly sensitive intelligence from standard operational view
    if dataset == "classified_intelligence.json" and op_record.get("classification") in ["SENSITIVE", "RESTRICTED"]:
        op_record["summary"] = "[CLASSIFIED - ACCESS VIA RESTRICTED DOMAIN]"
        op_record["suspectIdentifier"] = "[REDACTED]"
    
    operational_view.append(op_record)

    # 2. Analytics View (For statistical analysis, remove direct identifiers)
    an_record = record.copy()
    # Remove direct PII
    for field in ["callerName", "callerPhone", "name", "suspectIdentifier"]:
        if field in an_record:
            del an_record[field]
    # Generalize location to region level for analytics
    if "location" in an_record:
        # Simple heuristic: keep first word as region/town, drop street details
        an_record["location"] = an_record["location"].split(',')[0].strip() 
    
    analytics_view.append(an_record)

    # 3. Research View (For external research, fully anonymized)
    re_record = record.copy()
    # Remove all identifiable fields and internal IDs
    for field in ["callerName", "callerPhone", "name", "suspectIdentifier", "incidentId", "responderId", "dispatchId", "reportId", "eventId"]:
        if field in re_record:
            del re_record[field]
    # Generalize location completely
    if "location" in re_record:
        re_record["location"] = "[REGION ANONYMIZED]"
    # Remove sensitive summaries
    if "summary" in re_record:
        re_record["summary"] = "[CONTENT SANITIZED FOR RESEARCH]"
        
    research_view.append(re_record)

# Process all files
for filename in files:
    filepath = os.path.join(OUTPUT_DIR, filename)
    if not os.path.exists(filepath):
        continue
        
    with open(filepath, "r", encoding="utf-8") as f:
        records = json.load(f)

    for record in records:
        process_record(filename, record)

# Save the three views
views = {
    "operational_view.json": operational_view,
    "analytics_view.json": analytics_view,
    "research_view.json": research_view
}

for view_name, view_data in views.items():
    view_path = os.path.join(OUTPUT_DIR, view_name)
    with open(view_path, "w", encoding="utf-8") as f:
        json.dump(view_data, f, indent=4)
    print(f"Generated view: {view_path} (Total records: {len(view_data)})")

print("All data views generated successfully! Check the output folder.")