import json
import os

DATA_DIR = "data"

files = [
    "incidents.json",
    "responders.json",
    "intelligence.json",
    "dispatch.json",
    "audit.json",
]

for filename in files:
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        records = json.load(f)

    print(f"=== {filename} ===")
    print(f"Number of records: {len(records)}")
    print(f"First record: {records[0]}")
    print()