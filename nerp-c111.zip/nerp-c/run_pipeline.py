"""Run from any directory; fail on missing input instead of silently skipping it."""
import argparse
import hashlib
import json
from collections import Counter
from datetime import date
from pathlib import Path
from classify import FILES, IDS, LEVELS, classify_record
from generate_views import generate_views
from retention import ManagedArchive, determine_action, write_json

ROOT = Path(__file__).resolve().parent

def run(data_dir, output_dir, as_of, ingested_on, holds=()):
    if ingested_on > as_of:
        raise ValueError('Ingestion date cannot be in the future')
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    classified = {}
    hashes = {}
    for name in FILES:
        raw = (Path(data_dir) / name).read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        records = json.loads(raw)
        ids = [r[IDS[name]] for r in records]
        if len(ids) != len(set(ids)):
            raise ValueError('Duplicate record IDs in ' + name)
        classified[name] = [classify_record(name, r) for r in records]
    # Links to more sensitive records must not be a route around classification.
    index = {r[IDS[n]]: r for n in FILES for r in classified[n]}
    for name, ref in (('dispatch.json', 'incidentId'), ('responders.json', 'currentAssignment'),
                      ('audit.json', 'resource')):
        for r in classified[name]:
            target = index.get(r.get(ref))
            floor = target['classification'] if target else 'RESTRICTED'
            if LEVELS[floor] > LEVELS[r['classification']]:
                r['classification'] = floor
                r['reasons'].append('Classification inherited from linked resource (or unknown reference)')
    valid_holds = {name + ':' + r[IDS[name]] for name in FILES for r in classified[name]}
    if set(holds) - valid_holds:
        raise ValueError('Unknown legal-hold identifier')
    archive = ManagedArchive(output_dir / 'managed_archive')
    report, active = [], {}
    for name in FILES:
        active[name] = []
        for r in classified[name]:
            decision = determine_action(name, r, as_of, ingested_on,
                                        name + ':' + r[IDS[name]] in holds)
            if archive.enforce(decision, r):
                active[name].append(r)
            report.append(decision)
        write_json(output_dir / ('classified_' + name), active[name])
    views = generate_views(active)
    for name, view in views.items():
        write_json(output_dir / name, view)
    write_json(output_dir / 'retention_governance_report.json', report)
    # Checksums detect accidental changes only; no claim of adversary-resistant signing.
    artifacts = sorted(output_dir.glob('*.json'))
    manifest = {'asOf': as_of.isoformat(), 'ingestedOn': ingested_on.isoformat(),
                'inputSha256': hashes, 'actions': dict(Counter(r['action'] for r in report)),
                'activeCounts': {n: len(rows) for n, rows in active.items()},
                'artifactSha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts
                                   if p.name != 'manifest.json'}}
    write_json(output_dir / 'manifest.json', manifest)
    return manifest

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir', type=Path, default=ROOT / 'data')
    p.add_argument('--output-dir', type=Path, default=ROOT / 'output')
    p.add_argument('--as-of', type=date.fromisoformat, default=date.today())
    p.add_argument('--ingested-on', type=date.fromisoformat, required=True,
                   help='Explicit lifecycle anchor for supplied undated records; do not advance on rerun')
    p.add_argument('--hold', action='append', default=[], help='dataset.json:recordId; repeatable')
    args = p.parse_args()
    print(json.dumps(run(args.data_dir, args.output_dir, args.as_of, args.ingested_on, args.hold), indent=2))

if __name__ == '__main__':
    main()
