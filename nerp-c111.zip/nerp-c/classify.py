"""C1/C2: conservative local policy, not UK government classification equivalence."""
from copy import deepcopy

FILES = ('incidents.json', 'responders.json', 'intelligence.json', 'dispatch.json', 'audit.json')
LEVELS = {'PUBLIC': 0, 'OPERATIONAL': 1, 'SENSITIVE': 2, 'RESTRICTED': 3}
HINT_MAPPING = {'OFFICIAL': 'OPERATIONAL', 'CONFIDENTIAL': 'SENSITIVE',
                'SECRET': 'SENSITIVE', 'TOP SECRET': 'RESTRICTED'}
IDS = {'incidents.json': 'incidentId', 'responders.json': 'responderId',
       'intelligence.json': 'reportId', 'dispatch.json': 'dispatchId', 'audit.json': 'eventId'}

def classify_record(dataset, record):
    if dataset not in FILES:
        raise ValueError('Unknown dataset; manual review required')
    result = deepcopy(record)
    level, tags, reasons = 'OPERATIONAL', [], ['Internal operational data; not approved for public release']
    def raise_to(new, tag, reason):
        nonlocal level
        if LEVELS[new] > LEVELS[level]:
            level = new
        if tag not in tags:
            tags.append(tag)
        reasons.append(reason)
    if dataset == 'intelligence.json':
        hint = str(record.get('classificationHint', '')).strip().upper()
        raise_to(HINT_MAPPING.get(hint, 'RESTRICTED'), 'INTELLIGENCE',
                 'Metadata hint: ' + (hint or 'MISSING'))
        if hint not in HINT_MAPPING:
            tags.append('MANUAL_REVIEW')
        # Even low-threat intelligence may reveal investigative sources.
        raise_to('SENSITIVE', 'INTELLIGENCE', 'Protect intelligence sources and methods')
        if str(record.get('threatLevel', '')).upper() in ('SEVERE', 'CRITICAL'):
            raise_to('RESTRICTED', 'NATIONAL_SECURITY', 'Severe/critical threat metadata')
    for field in ('callerName', 'callerPhone', 'name', 'suspectIdentifier'):
        value = record.get(field)
        if value and str(value).strip().upper() not in ('N/A', 'NONE', 'UNKNOWN'):
            raise_to('SENSITIVE', 'PII', 'Personal identifier field: ' + field)
    text = ' '.join(str(record.get(k, '')) for k in ('summary', 'incidentType')).lower()
    if any(x in text for x in ('medical', 'casualt', 'injur')) or record.get('casualties', 0):
        raise_to('SENSITIVE', 'MEDICAL', 'Health/casualty information')
    if any(x in text for x in ('terror', 'sabotage', 'coordinated attack')):
        raise_to('RESTRICTED', 'NATIONAL_SECURITY', 'National-security content indicator')
    elif any(x in text for x in ('malware', 'critical infrastructure', 'chemical spill', 'collapse')):
        raise_to('SENSITIVE', 'HIGH_RISK', 'Sensitive operational hazard')
    if dataset == 'audit.json':
        raise_to('SENSITIVE', 'AUDIT_CRITICAL', 'Audit actors/actions/resource links reveal operations')
    result.update(classification=level, sensitivityTags=sorted(tags), reasons=reasons,
                  integrityRequirement='HIGH' if dataset == 'audit.json' else 'VERIFIED_SOURCE',
                  integrityStatus='UNVERIFIED')
    return result
