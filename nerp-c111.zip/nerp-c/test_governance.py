import hashlib
import json
import tempfile
import unittest
from datetime import date
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken
from classify import FILES, classify_record
from generate_views import OP_FIELDS, AN_FIELDS
from retention import ManagedArchive, add_years, determine_action
from run_pipeline import ROOT, run

class GovernanceTests(unittest.TestCase):
    def test_classification_and_no_mutation(self):
        original = {'reportId': 'X', 'classificationHint': 'TOP SECRET', 'summary': 'weather'}
        result = classify_record('intelligence.json', original)
        self.assertEqual(result['classification'], 'RESTRICTED')
        self.assertNotIn('classification', original)
        unknown = classify_record('intelligence.json', {'reportId': 'X'})
        self.assertEqual(unknown['classification'], 'RESTRICTED')
        self.assertIn('MANUAL_REVIEW', unknown['sensitivityTags'])
        self.assertEqual(classify_record('dispatch.json', {})['classification'], 'OPERATIONAL')
        self.assertEqual(classify_record('audit.json', {})['classification'], 'SENSITIVE')
        self.assertEqual(classify_record('incidents.json', {'incidentType':'Medical Emergency'})['classification'], 'SENSITIVE')
        self.assertEqual(classify_record('incidents.json', {'incidentType':'Terrorism Threat'})['classification'], 'RESTRICTED')
        self.assertEqual(classify_record('audit.json', {})['integrityStatus'], 'UNVERIFIED')

    def test_dates_and_boundaries(self):
        r = {'incidentId': 'arbitrary2', 'timestamp': '2010-11-03T10:00:00Z', 'classification': 'SENSITIVE'}
        args = ('incidents.json', r)
        self.assertEqual(determine_action(*args, date(2011,11,3), date(2010,11,3))['action'], 'RETAIN')
        self.assertEqual(determine_action(*args, date(2012,11,3), date(2010,11,3))['action'], 'ARCHIVE')
        self.assertEqual(determine_action(*args, date(2020,11,3), date(2010,11,3))['action'], 'SECURE_DELETE')
        self.assertEqual(determine_action(*args, date(2020,11,3), date(2010,11,3), True)['action'], 'LEGAL_HOLD')
        self.assertEqual(add_years(date(2024,2,29), 1), date(2025,2,28))
        with self.assertRaises(ValueError):
            determine_action(*args, date(2009,1,1), date(2010,1,1))
        r['timestamp'] = 'invalid'
        with self.assertRaises(ValueError):
            determine_action(*args, date(2026,1,1), date(2010,1,1))

    def test_archive_integrity_deletion_and_tombstone(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = ManagedArchive(tmp)
            r = {'incidentId': 'X', 'classification': 'SENSITIVE', 'timestamp':'2000-01-01'}
            d = determine_action('incidents.json', r, date(2002,1,1), date(2000,1,1))
            self.assertFalse(store.enforce(d, r))
            self.assertEqual(store.read('incidents.json','X'), r)
            _, key, blob = store.paths('incidents.json', 'X')
            encrypted = blob.read_bytes()
            self.assertNotIn(b'incidentId', encrypted)
            corrupted = bytearray(encrypted); corrupted[-10] ^= 1
            with self.assertRaises(InvalidToken):
                Fernet(key.read_bytes()).decrypt(bytes(corrupted))
            d = determine_action('incidents.json', r, date(2010,1,1), date(2000,1,1))
            store.enforce(d, r)
            self.assertFalse(key.exists()); self.assertFalse(blob.exists())
            with self.assertRaises(FileNotFoundError):
                store.read('incidents.json','X')
            new = ManagedArchive(tmp)
            d = determine_action('incidents.json', r, date(2001,1,1), date(2000,1,1))
            self.assertFalse(new.enforce(d, r))
            self.assertEqual(d['action'], 'SECURE_DELETE')

    def test_supplied_data_views_and_repeatability(self):
        before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data').glob('*.json')}
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            m = run(ROOT/'data', out, date(2026,11,5), date(2026,11,3))
            self.assertEqual(m['actions'], {'RETAIN':100})
            self.assertEqual(sum(m['activeCounts'].values()), 100)
            self.assertEqual(m, run(ROOT/'data', out, date(2026,11,5), date(2026,11,3)))
            for name, fields in [('operational', OP_FIELDS), ('analytics', AN_FIELDS)]:
                rows = json.loads((out/(name+'_view.json')).read_text())
                self.assertGreater(len(rows), 0)
                for r in rows:
                    self.assertLessEqual(set(r), set(fields[r['dataset']]) | {'dataset','classification','integrityStatus'})
                    self.assertNotEqual(r['classification'], 'RESTRICTED')
                text = json.dumps(rows)
                for forbidden in ('Alice Turner','07700110001','SUBJ-', 'reportSource','currentAssignment' if name=='analytics' else 'callerName'):
                    self.assertNotIn(forbidden, text)
            research = json.loads((out/'research_view.json').read_text())
            self.assertEqual(research['releaseStatus'], 'REVIEW_REQUIRED')
            self.assertGreater(len(research['groups']),0)
            for g in research['groups']:
                self.assertEqual(set(g), {'dataset','assignedAgency','count'})
                self.assertGreaterEqual(g['count'],5)
            audit = json.loads((out/'classified_audit.json').read_text())
            self.assertTrue(all(r['classification'] != 'PUBLIC' for r in audit))
            self.assertEqual(next(r for r in audit if r['resource']=='INT-001')['classification'], 'RESTRICTED')
        self.assertEqual(before, {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data').glob('*.json')})

    def test_lifecycle_removes_exports_and_holds(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            run(ROOT/'data', out, date(2026,11,5), date(2026,11,3))
            m = run(ROOT/'data', out, date(2028,11,3), date(2026,11,3))
            self.assertEqual(m['actions'], {'ARCHIVE':100})
            self.assertEqual(json.loads((out/'operational_view.json').read_text()), [])
            self.assertEqual(sum(m['activeCounts'].values()), 0)
            self.assertEqual(len(list((out/'managed_archive').glob('*.key'))),100)
            m = run(ROOT/'data', out, date(2046,11,3), date(2026,11,3), ['audit.json:AUD-001'])
            self.assertEqual(m['actions'], {'SECURE_DELETE':99, 'LEGAL_HOLD':1})
            self.assertEqual(len(list((out/'managed_archive').glob('*.key'))),1)
            m = run(ROOT/'data', out, date(2046,11,3), date(2026,11,3))
            self.assertEqual(m['actions'], {'SECURE_DELETE':100})
            self.assertEqual(list((out/'managed_archive').glob('*.key')),[])
            self.assertEqual(list((out/'managed_archive').glob('*.enc')),[])
            m = run(ROOT/'data', out, date(2026,11,5), date(2026,11,3))
            self.assertEqual(m['actions'], {'SECURE_DELETE':100})
            self.assertEqual(json.loads((out/'analytics_view.json').read_text()),[])

    def test_missing_input_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):
                run(Path(tmp)/'missing',Path(tmp)/'out',date(2026,11,5),date(2026,11,3))

if __name__ == '__main__':
    unittest.main(verbosity=2)
