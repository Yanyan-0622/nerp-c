# Scope and evidence index

This is the Part C contribution to the group assurance portfolio. It replaces earlier claims and screenshots; it does not establish complete NERP readiness. Evidence: evidence/unittest.txt; evidence/review_results.json; evidence/word_counts.json; output/manifest.json; output/classified_*.json; output/*_view.json; output/retention_governance_report.json; and test_governance.py. Reproduce with: python run_pipeline.py --as-of 2026-11-05 --ingested-on 2026-11-03; python -m unittest -v test_governance. Python 3.12.14 and cryptography 50.0.0 were used. Fresh dependency installation was not tested.

# C1/C2 - Classification schema and observed distribution

PUBLIC: approved public releases only. OPERATIONAL: internal routing baseline. SENSITIVE: identifiers, health information, source-protected intelligence and audit. RESTRICTED: severe/critical or national-security content, unknown intelligence hints and sensitive linked resources. Whole-record highest-label handling is conservative. Original audit and dispatch outputs each contained twenty PUBLIC records; corrected labels eliminate that default.
incidents.json: {'SENSITIVE': 18, 'RESTRICTED': 2}; responders.json: {'SENSITIVE': 13, 'RESTRICTED': 7}; intelligence.json: {'RESTRICTED': 6, 'SENSITIVE': 14}; dispatch.json: {'SENSITIVE': 18, 'RESTRICTED': 2}; audit.json: {'RESTRICTED': 7, 'SENSITIVE': 13}
Source-integrity requirements are separate from provenance verification: all records remain UNVERIFIED. Original data.zip and all five corrected source JSONs are byte-identical (see recorded hashes).

# C3 - Information-flow evidence

Original research output retained actor/resource in twenty rows, currentAssignment in twenty, unit in twenty, exact timestamps in forty, station/clearanceLevel in twenty, region/classificationHint in twenty, and reasons in all one hundred. Removing primary keys therefore did not establish anonymisation. Original analytics retained intelligence summaries and detailed locations.
The corrected allowlists exclude those release channels. Active inputs contain one hundred records, while general operational and analytics projections each contain forty-nine eligible rows; restricted rows, intelligence and audit are intentionally absent. Research contains only agency-level incident counts: Ambulance five, Fire seven, Police six. Each group has at least five members. The output is REVIEW_REQUIRED and SENSITIVE; it is not an unrestricted public release. Original linkage defects are addressed, but auxiliary-data and repeated-release attacks remain possible. Clearance, task scope and emergency access require Part D integration.

# C4 - Retention decisions and enforcement evidence

Original retention.py assigned ten ARCHIVE and ten SECURE_DELETE labels based on ID suffixes, leaving eighty RETAIN labels. It neither computed age nor archived/destroyed data. Corrected current-instance output assigns one hundred RETAIN actions at 2026-11-05, with explicit date anchors and expiry dates.
The lifecycle test uses the actual one-hundred-record snapshot in a temporary managed store. At 2028-11-03 all one hundred records are archived: one hundred individual keys exist and active exports are empty. At 2046-11-03, a hold on AUD-001 leaves one encrypted held record and ninety-nine destroyed managed copies. Releasing the hold removes the final key/ciphertext. A subsequent earlier-date run cannot repopulate destroyed exports because tombstones persist. Baseline source fixtures remain unchanged. Policy years are illustrative design assumptions; legal holds and the later Part E requirement are separate governance inputs.

# Failure and mitigation experiments

Classification ambiguity: missing intelligence hints become RESTRICTED with MANUAL_REVIEW; multiple rules cannot lower a record. Confidentiality/integrity labelling is not authenticity.
Invalid/future date: raises an error instead of deleting on an uncertain lifecycle anchor. Missing input: raises FileNotFoundError instead of reporting partial success.
Encrypted-archive tampering: a modified ciphertext raises cryptography.fernet.InvalidToken. This verifies authenticated encryption rather than merely checking file existence.
Destruction: after expiry, both key and blob are absent and archive retrieval fails with FileNotFoundError; a persisted tombstone prevents re-ingestion. Legal hold prevents expiry until explicitly released.
Repeatability: identical snapshot, dates and managed state yield identical active outputs and manifest. Six test methods completed successfully, with no skipped tests. See exact captured runner output below.

# Actual test log

test_archive_integrity_deletion_and_tombstone (test_governance.GovernanceTests.test_archive_integrity_deletion_and_tombstone) ... ok
test_classification_and_no_mutation (test_governance.GovernanceTests.test_classification_and_no_mutation) ... ok
test_dates_and_boundaries (test_governance.GovernanceTests.test_dates_and_boundaries) ... ok
test_lifecycle_removes_exports_and_holds (test_governance.GovernanceTests.test_lifecycle_removes_exports_and_holds) ... ok
test_missing_input_fails (test_governance.GovernanceTests.test_missing_input_fails) ... ok
test_supplied_data_views_and_repeatability (test_governance.GovernanceTests.test_supplied_data_views_and_repeatability) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.704s

OK


# Residual risks and assurance argument

Claim: the prototype demonstrates conservative classification, minimised views and enforceable managed-copy lifecycle behaviour for this supplied snapshot. Support: classification/flow/retention tests, generated artifacts and byte-identical input hashes. Limitation: no claim of complete system accreditation, legal compliance or production readiness follows.
The operational view is still dataset-wide; Part D must add authenticated user-specific checks and controlled emergency access. Classification uses heuristic rules on a known schema. Cohort suppression is not proof of anonymity, so research requires human release review. SHA-256 manifests lack adversarial authenticity. Encryption keys are stored locally beside ciphertext under owner-only permissions, not in a separate KMS. Deletion excludes source fixtures, old ZIPs, external copies, snapshots and backups and is not physical erasure. Retention anchors for undated records are assumptions, and production must avoid deleting active cases.
The pipeline assumes one writer and does not atomically publish all artifacts. Persist legal holds, ingestion anchors and policy versions outside CLI arguments; integrate protected key custody, signed provenance, audit trails and backup lifecycle before deployment. Availability costs include excluding restricted records and keeping archived/held data out of ordinary views; authorised operational routes remain essential.