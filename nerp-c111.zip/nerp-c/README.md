# NERP Part C — corrected prototype

Use the existing checkout; each cloud task is already isolated. No Git worktree is needed.

## Run

Tested on Python 3.12.14 and cryptography 50.0.0. Python 3.10+ is required.

```sh
cd /path/to/nerp-c
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python run_pipeline.py --as-of 2026-11-05 --ingested-on 2026-11-03
python -m unittest -v test_governance
```

The dependency is already installed in the review environment; the pipeline and tests ran there. Installing into a fresh virtual environment was not tested. No web service, database, or API credentials are needed. Run `run_pipeline.py`, not the old three-script sequence. `classify.py`, `generate_views.py`, and `retention.py` are now import-safe modules. All input files are mandatory. The single-writer pipeline exits nonzero for missing input, malformed dates, unknown classification or hold identifiers.

`--as-of` defaults to today's date. Always keep `--ingested-on 2026-11-03` for this snapshot: intelligence, responders and dispatch lack full retention dates, so an explicitly documented ingestion-date assumption is used. This date is a reproducible coursework assumption, not metadata present in every supplied record. Incidents and audit use their actual timestamps. Production needs validated closure/supersession dates; active operational records must not expire solely due to age.

`output/classified_*.json` contains active records only. Operational/analytics views are allowlist projections of eligible active incidents, dispatch and responders, excluding RESTRICTED records. Classified source exports still require high-trust storage. Research output is three agency-level incident counts, with groups smaller than five suppressed; it requires human release review and remains SENSITIVE. No public-release authorisation is implemented. The output has 49 operational rows, 49 analytics rows, and 3 research groups, not 100 rows in every view.

## Lifecycle demonstration (isolated scratch outputs)

```sh
python run_pipeline.py --as-of 2028-11-03 --ingested-on 2026-11-03 --output-dir /tmp/nerp-lifecycle-demo
python run_pipeline.py --as-of 2046-11-03 --ingested-on 2026-11-03 --output-dir /tmp/nerp-lifecycle-demo --hold audit.json:AUD-001
python run_pipeline.py --as-of 2046-11-03 --ingested-on 2026-11-03 --output-dir /tmp/nerp-lifecycle-demo
```

First command archives all 100 records into individually encrypted Fernet blobs. Second destroys 99 managed copies and holds AUD-001; third releases that hold and destroys the final managed copy. No held/archived record is exported to ordinary views. The ledger persists tombstones to prevent re-ingestion into the same output directory. Always repeat legal-hold options on every run until an authorised release; the CLI is a demonstration policy input, not a hold-management service. A hold after destruction fails because recovery is impossible within the managed store. Unit tests run the lifecycle in temporary directories and verify decryption, tamper rejection, key/blob removal and empty exports.

## Boundaries and integration with Parts D/E

- The four labels are local coursework labels, not an official equivalence to UK government classifications. OFFICIAL never means public. Source hints set floors; PII, health information, threat metadata and linked-resource classification can raise them. PUBLIC is reserved for a separate approved release process.
- Integrity requirement is distinct from verified provenance. JSON input is UNVERIFIED; declaring audit integrity HIGH does not authenticate it. A checksum manifest detects accidental corruption only. Production requires signed provenance, protected append-only audit storage and Part D's authenticated ACM/BLP/Biba decisions.
- Views are candidate dataset-wide projections, not per-user authorisation. Part D must enforce clearance, role, region and assignment. Contact details, restricted incidents, audit and intelligence remain on protected source paths; approved responders must obtain essential restricted information through an authorised, audited workflow. Part C alone is not a deployable emergency-response system.
- Research is deliberately coarse and still requires disclosure review. Cohort size five does not guarantee anonymity against auxiliary knowledge or repeated-release differencing. Avoid arbitrary queryable slices; no claim of full anonymisation or automatic BLP downgrading is made.
- Retention periods 2/5/10/20 years and archive-after-two-years are illustrative policy choices, not legal requirements stated in the brief. A legal hold overrides expiry. The twenty-year requirement in E is a later change scenario, not the baseline law. Archive reduces active storage, not total retained storage.
- Cryptographic deletion is scoped to this prototype's managed archive and rewritten current exports. Original assignment fixtures, the original submitted archive, old exports, backups, OS caches, snapshots and third-party copies are outside the guarantee. File unlink is not physical SSD erasure. Production needs envelope encryption, separate KMS custody, backup lifecycle controls and auditable key destruction.
- Local archive keys sit beside ciphertext under owner-only permissions, sufficient only for a single-user demonstration. Do not distribute real keys. The shipped managed archive contains an empty ledger and no keys or encrypted records. Treat all supplied records as coursework fixtures.
- Pipeline is single-writer and not transactional across all files. Do not read exports during a run; production requires atomic publication, concurrency control, stable ingestion metadata and durable hold state. Classification rules are heuristics over the known flat schema, not semantic analysis or proof of source authenticity.

The two corrected documents are Part C inserts for the group's combined technical report and assurance portfolio. Merge them into the group's PDFs. This archive is not a complete Parts A–E submission. Each student must separately supply their own reflective log.
