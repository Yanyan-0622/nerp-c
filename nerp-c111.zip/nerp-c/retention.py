"""C4: real dates, encrypted managed archive, key deletion scoped to managed copies."""
import calendar
import hashlib
import json
import os
from datetime import date
from pathlib import Path
from cryptography.fernet import Fernet
from classify import IDS, LEVELS

YEARS = {'PUBLIC': 2, 'OPERATIONAL': 5, 'SENSITIVE': 10, 'RESTRICTED': 20}

def add_years(day, years):
    year = day.year + years
    return date(year, day.month, min(day.day, calendar.monthrange(year, day.month)[1]))

def determine_action(dataset, record, as_of, ingested_on, legal_hold=False):
    level = record.get('classification')
    if level not in LEVELS:
        raise ValueError('Unrecognised classification; do not delete')
    years = 20 if dataset == 'audit.json' else YEARS[level]
    # Supplied intelligence/responders/dispatch have no lifecycle date.
    raw = record.get('closedAt') or record.get('timestamp')
    basis = 'closedAt' if record.get('closedAt') else 'timestamp'
    if not raw:
        raw, basis = ingested_on.isoformat(), 'explicit ingestion-date assumption'
    start = date.fromisoformat(str(raw)[:10])
    if start > as_of:
        raise ValueError('Future retention anchor; manual review required')
    expiry = add_years(start, years)
    archive_on = add_years(start, min(2, years))
    action = ('LEGAL_HOLD' if legal_hold else 'SECURE_DELETE' if as_of >= expiry
              else 'ARCHIVE' if as_of >= archive_on else 'RETAIN')
    return dict(recordId=record[IDS[dataset]], dataset=dataset, classification=level,
                retention_years=years, anchor=start.isoformat(), anchorBasis=basis,
                expiresOn=expiry.isoformat(), action=action,
                policyBasis='Coursework design assumption, not a stated statutory period')

def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix(path.suffix + '.tmp')
    with open(temp, 'w', encoding='utf-8') as f:
        os.chmod(temp, 0o600)
        json.dump(obj, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write('\n')
    os.replace(temp, path)

class ManagedArchive:
    """Single-writer demo. Keys beside ciphertext are NOT a production KMS."""
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.ledger_path = self.root / 'ledger.json'
        self.ledger = json.loads(self.ledger_path.read_text()) if self.ledger_path.exists() else {}

    def paths(self, dataset, rid):
        token = hashlib.sha256((dataset + ':' + rid).encode()).hexdigest()
        return token, self.root / (token + '.key'), self.root / (token + '.enc')

    def enforce(self, decision, record):
        token, key_path, blob_path = self.paths(decision['dataset'], decision['recordId'])
        previous = self.ledger.get(token, {})
        if previous.get('action') == 'SECURE_DELETE':
            if decision['action'] == 'LEGAL_HOLD':
                raise ValueError('Hold requested after destruction; record cannot be restored')
            decision['action'] = 'SECURE_DELETE'
            decision['note'] = 'Existing tombstone prevents re-ingestion'
        elif previous.get('action') == 'ARCHIVE' and decision['action'] == 'RETAIN':
            decision['action'] = 'ARCHIVE'
        action = decision['action']
        if action in ('ARCHIVE', 'LEGAL_HOLD'):
            if not key_path.exists():
                key_path.write_bytes(Fernet.generate_key())
                key_path.chmod(0o600)
            blob_path.write_bytes(Fernet(key_path.read_bytes()).encrypt(
                json.dumps(record, sort_keys=True).encode()))
            blob_path.chmod(0o600)
        if action == 'SECURE_DELETE':
            key_path.unlink(missing_ok=True)
            blob_path.unlink(missing_ok=True)
        self.ledger[token] = dict(decision)
        write_json(self.ledger_path, self.ledger)
        return action == 'RETAIN'

    def read(self, dataset, rid):
        _, key, blob = self.paths(dataset, rid)
        return json.loads(Fernet(key.read_bytes()).decrypt(blob.read_bytes()))
