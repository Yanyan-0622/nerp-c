"""C3: explicit field allowlists; this transformation is not an access-control engine."""
from collections import Counter
from copy import deepcopy

OP_FIELDS = {
    'incidents.json': ('incidentId', 'timestamp', 'location', 'incidentType', 'casualties', 'priority', 'assignedAgency'),
    'dispatch.json': ('dispatchId', 'incidentId', 'unit', 'departureTime', 'arrivalTime', 'status'),
    'responders.json': ('responderId', 'role', 'station', 'currentAssignment'),
}
AN_FIELDS = {'incidents.json': ('assignedAgency', 'priority', 'casualties'),
             'dispatch.json': ('status',), 'responders.json': ('role',)}

def generate_views(datasets, k=5):
    if k < 5:
        raise ValueError('Research minimum cohort size must be at least 5')
    operational, analytics = [], []
    for dataset in OP_FIELDS:
        for r in datasets[dataset]:
            # Restricted incident types are not automatically declassified.
            if r['classification'] == 'RESTRICTED':
                continue
            op = {key: deepcopy(r[key]) for key in OP_FIELDS[dataset] if key in r}
            op.update(dataset=dataset, classification=r['classification'],
                      integrityStatus=r['integrityStatus'])
            operational.append(op)
            an = {key: deepcopy(r[key]) for key in AN_FIELDS[dataset] if key in r}
            an.update(dataset=dataset, classification='SENSITIVE', integrityStatus='UNVERIFIED')
            analytics.append(an)
    # Fixed single partition; no record-level rows, free text, identifiers or joins.
    counts = Counter(r['assignedAgency'] for r in datasets['incidents.json']
                     if r['classification'] != 'RESTRICTED' and r.get('assignedAgency'))
    research = [{'dataset': 'incidents.json', 'assignedAgency': agency, 'count': n}
                for agency, n in sorted(counts.items()) if n >= k]
    return {'operational_view.json': operational, 'analytics_view.json': analytics,
            'research_view.json': {'releaseStatus': 'REVIEW_REQUIRED', 'minimumCohortSize': k,
                                   'classification': 'SENSITIVE', 'groups': research}}
